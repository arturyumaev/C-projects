#include <stdio.h>

int main(void)
{
    int number_of_weeks = 56;
	
    printf("Year has %d weeks.\n", number_of_weeks);
	
    return 0;
}
